------------------------------------------------------

               Projet Takuzu - L1
              Rendu le 15 mai 2022

------------------------------------------------------

Le projet a été réalisé par Tom Dizdarevic et Thambir.

Le but de ce projet est de réaliser un Takuzu jouable par un joueur ou un ordinateur.

Instructions de lancement :
- Exécuter le fichier "main.exe"

Instructions de compilage : 
- Ouvrir un IDE en important les fichiers du .zip
- Lancer le programme/Compiler en faisant attention de bien inclure TOUS les fichiers ".c"

L'utilisation du programme est possible via Linux en utilisant wine.