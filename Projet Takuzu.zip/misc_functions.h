#ifndef MISC_FUNCTIONS_H
#define MISC_FUNCTIONS_H

int main_menu();
int clean_console();
int safe_type(int lim);
int safe_type_0(int lim);
int rand_number(int min, int max);

#endif