#ifndef AUTO_GRID_RESOLUTION_H
#define AUTO_GRID_RESOLUTION_H

int auto_grid_resolution();
int verify_grid_cell(int** grid, int size, int lin, int col);
int verify_line(int** grid, int size, int lin);

#endif