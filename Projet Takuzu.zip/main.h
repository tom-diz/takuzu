#ifndef MAIN_H
#define MAIN_H
#include <stdio.h>
#include <windows.h>
#define BLUE 1
#define CYAN 11
#define RED 12
#define WHITE 15

int color_init();
int set_color(int k);

#endif